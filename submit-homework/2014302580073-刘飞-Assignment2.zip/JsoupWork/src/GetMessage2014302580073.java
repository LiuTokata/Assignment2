import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class GetMessage2014302580073 
{

	public static void main(String[] args) throws Exception
	{
		// get URL
		String gradeUrl="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Quan Yuan";
		//��ȡhtml
		Document doc = Jsoup.connect(gradeUrl).get();
		//����txt�ļ�
		FileWriter fw=new FileWriter("F:\\java\\JsoupWork\\���Խ��\\file.txt");
		//ͨ��tag��ȡ��������
		Elements element1=doc.getElementsByTag("p");
		Elements element2=doc.getElementsByTag("h3");
		Element element3=element1.get(0);
		String y=element3.text();
		
		//��ȡ�ı�
		String x=element1.text();
		//ͨ���������ʽ��ȡ����
		Pattern pEmail = Pattern.compile("\\w+@\\w+\\.\\w+.\\w+");//ȷ�������ʽ
		Pattern pPhone = Pattern.compile("\\d{3}\\s\\d{8}");//ȷ���绰��ʽ
		//��������
		String Email;
		String Phone;
		//����ƥ��
		Matcher mEmail=pEmail.matcher(x);
		Matcher mPhone=pPhone.matcher(x);
		//���в��Ҳ����
		//System.out.println(element2.text());
		fw.write(element2.text()+"\r\n");
		int start=0;
		int end=7;
		char buf[]=new char[end-start];
		y.getChars(start, end, buf, 0);
		//System.out.println(buf);
		for(int i=0;i<7;i++)
		{
			fw.write(buf[i]);
			
		}
		fw.write("\r\n");
		start=7;
		end=18;
		char buf1[]=new char[end-start];
		y.getChars(start, end, buf1, 0);
		for(int i=1;i<11;i++)
		{
			fw.write(buf1[i]);
			
		}
		fw.write("\r\n");
		if(mEmail.find())
		{
			Email=mEmail.group();
			//System.out.println("Email��"+Email);
			fw.write("Email:"+Email+"\r\n");
		}
		if(mPhone.find())
		{
			Phone=mPhone.group();
			//System.out.println("��ϵ�绰��"+Phone);
			fw.write("��ϵ�绰��"+Phone+"\r\n");
		}
		fw.write("���ܣ�\r\n");
		//��ȡ���ܲ�������
		for(int i=4;i<10;i++)
		{
			element3 = element1.get(i);
			//System.out.println(element3.text());
			fw.write(element3.text()+"\r\n");
		}
		for(int i=12;i<14;i++)
		{
			element3 = element1.get(i);
			//System.out.println(element3.text());
			fw.write(element3.text()+"\r\n");
		}
		fw.close();
	}

}